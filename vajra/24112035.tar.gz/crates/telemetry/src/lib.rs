//! Telemetry - Metrics and logging
//! TODO: Implement

pub struct Metrics;

#[cfg(test)]
mod tests {
	use super::*;

	#[test]
	fn create_metrics() {
		let _ = Metrics;
	}
}
