/*
 Simple example usage placeholder.

 Replace content with a small program that uses the workspace crates.
*/
fn main() {
    println!("vajra simple_scan example placeholder");
}
